/** Automatically generated file. DO NOT MODIFY */
package com.example.ddms;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}