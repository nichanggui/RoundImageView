package com.example.ddms;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.android.ddmlib.AndroidDebugBridge;
import com.android.ddmlib.IDevice;
import com.android.ddmlib.IShellOutputReceiver;
import com.android.ddmlib.RawImage;

/**
 * copy from http://bbs.csdn.net/topics/390502035. modify by Geek_Soledad
 */
public class AdbUtil {
	public static IDevice connect() {
		// init the lib
		// [try to] ensure ADB is running
//		String adbLocation = System.getProperty("com.android.screenshot.bindir"); //$NON-NLS-1$
//		if (adbLocation != null && adbLocation.length() != 0) {
//			adbLocation += File.separator + "adb"; //$NON-NLS-1$
//		} else {
//			adbLocation = "adb"; //$NON-NLS-1$
//		}

		AndroidDebugBridge.init(false /* debugger support */);

//		AndroidDebugBridge bridge = AndroidDebugBridge.createBridge(adbLocation, true /* forceNewBridge */);
		AndroidDebugBridge bridge = AndroidDebugBridge.createBridge();

		// we can't just ask for the device list right away, as the internal
		// thread getting
		// them from ADB may not be done getting the first list.
		// Since we don't really want getDevices() to be blocking, we wait
		// here manually.
		int count = 0;
		while (bridge.hasInitialDeviceList() == false) {
			try {
				Thread.sleep(100);
				count++;
			} catch (InterruptedException e) {
				// pass
			}

			// let's not wait > 10 sec.
			if (count > 100) {
				System.err.println("Timeout getting device list!");
				return null;
			}
		}

		// now get the devices
		IDevice[] devices = bridge.getDevices();

		if (devices.length == 0) {
			System.out.println("No devices found!");
			return null;
		}

		return devices[0];
	}

	public static BufferedImage screenShot(IDevice device) {
		RawImage rawImage;
		try {
			rawImage = device.getScreenshot();
		} catch (Exception ioe) {
			System.out.println("Unable to get frame buffer: " + ioe.getMessage());
			return null;
		}

		// device/adb not available?
		if (rawImage == null)
			return null;

		// convert raw data to an Image
		BufferedImage image = new BufferedImage(rawImage.width, rawImage.height, BufferedImage.TYPE_INT_ARGB);

		int index = 0;
		int IndexInc = rawImage.bpp >> 3;
		for (int y = 0; y < rawImage.height; y++) {
			for (int x = 0; x < rawImage.width; x++) {
				int value = rawImage.getARGB(index);
				index += IndexInc;
				image.setRGB(x, y, value);
			}
		}
		return image;
	}

	/**
	 * Grab an image from an ADB-connected device.
	 */
	public static boolean screenShotAndSave(IDevice device, String filepath) throws IOException {
		boolean result = ImageIO.write(screenShot(device), "png", new File(filepath));
		if (result) {
			System.out.println("file is saved in:" + filepath);
		}
		return result;
	}

	public static void terminate() {
		AndroidDebugBridge.terminate();
	}
	
	public static void executeShellCommand(IDevice device,String commond){
		IShellOutputReceiver receiver = new IShellOutputReceiver() {
			
			@Override
			public boolean isCancelled() {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public void flush() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void addOutput(byte[] arg0, int arg1, int arg2) {
				// TODO Auto-generated method stub
				
			}
		};
		try {
			device.executeShellCommand(commond, receiver);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
