package com.example.ddms;

import com.android.ddmlib.IDevice;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {

	IDevice device ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void onClick(View view) {
		if(device == null){
			Toast.makeText(MainActivity.this, "connect.....", Toast.LENGTH_LONG).show();
			device = AdbUtil.connect();
		}
		String result = DDMS.startTap(device);
		if (TextUtils.isEmpty(result)) {
			Toast.makeText(MainActivity.this, "OK success!", Toast.LENGTH_LONG).show();
		}else{
			Toast.makeText(MainActivity.this, result, Toast.LENGTH_LONG).show();
		}
	}
}
