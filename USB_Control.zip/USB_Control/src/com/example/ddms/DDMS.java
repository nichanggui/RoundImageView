package com.example.ddms;

import com.android.ddmlib.IDevice;

public class DDMS {
	
	public static String  startTap(IDevice device) {
		String result = "";
		try {
//			 AdbUtil.screenShotAndSave(device, "/temp.png"); //这是截图
			
			AdbUtil.executeShellCommand(device, "input tap 200 200"); //这是点击
		} catch (Exception e) {
			e.printStackTrace();
			result = e.getMessage();
		}
		System.out.println("-------------");
		return result;
	}

}
